<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * everything you declare in config array
 * you can easily access it from the Banglalink library with an underscore
 * for example if you create $config['variable'] you can access it from library by simply calling $this->_variable
 */

#page access token
$config['api']	= "https://vas.banglalinkgsm.com";
$config['username']	= "your username";
$config['password']	= "your password";
$config['sender']	= "your masking"; 
  